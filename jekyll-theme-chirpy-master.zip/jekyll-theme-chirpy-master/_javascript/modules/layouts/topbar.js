import { displaySearch } from '../components/search-display';

export function initTopbar() {
  displaySearch();
}
